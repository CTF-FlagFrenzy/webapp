import{a as t}from"../chunks/entry.Cfaor06_.js";export{t as start};
